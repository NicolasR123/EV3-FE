function validar() {
    var ret_contraseña = validar_contraseña();
    var ret_email = validar_email();
    var ret_tel = validar_telefono();
    var ret_comp = validar_comp();
    var ret_dir = validar_dirr();
    var ret_af = validar_aficion();
    var ret_comuna = validar_comuna();
    return ret_contraseña && ret_email && ret_tel && ret_comp && ret_dir && ret_af && ret_comuna;
}

   function validar_contra(s){

    contNumber = false;
    contLetter = false;
    
    for (let i of s) {
       
        console.log(i);
        if (contNumber && contLetter) {
            console.log("PASA");
            break;
        }

        if (isNaN(i)) {
            console.log("Tiene una letra");
            contNumber = true;

        }else{
            console.log("Tiene un numero");
            contLetter = true;
        }
        
        
    }
    console.log(contNumber);
    console.log(contLetter);
    return (contNumber && contLetter) 

   }

    function validar_contraseña(){
        var contrasena = document.getElementById("pass").value;
        var div = document.getElementById("err_pass");
       
        if (contrasena.length >= 3 && contrasena.length <= 6 && validar_contra(contrasena)) {
            div.innerText = ""
            
            return true;
          } else {
            div.innerText = "La contraseña no es valida";
            div.className = "text-danger";
            return false; 
          }
    }

    function validar_email() {
        var email = document.getElementById("email").value;
        var div = document.getElementById("err_email");
        var arroba = email.indexOf("@");
        var punto = email.lastIndexOf(".");
        if (arroba < 1) {
            div.innerText = "El correo electrónico no es valido";
            div.className = "text-danger";
            return false;
        } else {
            if (arroba < 2) {
                div.innerText = "El nombre de usuario del correo no es válido";
                div.className = "text-danger";
                return false;
            } else {
                if (arroba + 3 > punto || punto + 1 >= email.length - 1 ) {
                    div.innerText = "El nombre de dominio no es válido";
                    div.className = "text-danger";
                    return false;
                } else {
                    div.innerText = "";
                    return true;
                }
            }
        }
    }

    function validar_telefono(){

        var tel = document.getElementById("fono").value;
        var div = document.getElementById("err_fono");
        var mas = tel.indexOf("+569");
        console.log("NUMERO");
        console.log(mas);
        if (mas>=0 && tel.length === 12) {
            div.innerText = ""
            return true;
        }else{
            div.innerText = "El numero de telefono no es valido, (+56912345678)";
            div.className = "text-danger";
            return false;
        }

    }

    function validar_comp(){

        var contraseña = document.getElementById("pass").value;
      
        var contraseña2 = document.getElementById("pass2").value;
        var div = document.getElementById("err_pass2");

        if (contraseña != contraseña2) {
            div.innerText = "Las contraseñas no coinciden";
            div.className = "text-danger";
            return false;
          } else {
            div.innerText = ""
            return true;
          }
    }

    function validar_dirr(){

        var direcc = document.getElementById("direcc").value;
        var div = document.getElementById("err_direcc");

        if (direcc.length > 0 && direcc.length <= 15) { 
            div.innerText = ""
            return true
        }else{
            div.innerText = "La direccion no es valida";
            div.className = "text-danger";
            return false;
        }

    }

    function validar_aficion(){

        var hijos = document.getElementById("aficiones-lista").children;
        var div = document.getElementById("err_aficion");

        if (hijos.length >= 2) {
            div.innerText = ""
            return true;
        }else{
            div.innerText = "Debe agregar 2 o mas aficiones";
            div.className = "text-danger";
            return false;

        }

    }

    function agregarAficion(){

        var inputAficion = document.getElementById("aficion");
        var listaAficiones = document.getElementById("aficiones-lista");

        var aficion = inputAficion.value; 
    if (aficion !== "") {
    
    var nuevoElementoLista = document.createElement("li");
    nuevoElementoLista.textContent = aficion;
    listaAficiones.appendChild(nuevoElementoLista);
    inputAficion.value = "";
    }
}

function validar_comuna() {
    var comuna = document.getElementById("comuna").value;
    var div = document.getElementById("err_comuna");
  
    if (comuna === "Seleccione una Comuna...") {
      div.innerText = "Debe seleccionar una Comuna";
      div.className = "text-danger";
      return false;
    } else {
      div.innerText = "";
      return true;
    }
  }
  
  
  
  
  
  
  
